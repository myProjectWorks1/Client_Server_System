

import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.Socket;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;



public class Monitor {
	
	 JFrame frame123 = new JFrame("Monitor");
	 private JPanel contentPane123;
	 private static String monitor = null;
	 private JTextPane textPane123 = null;
	 private JTextPane textPane_1234 = null;
	 alarmService alarmobject;
	 private JComboBox comboBox1;
	 
	 
	 
	 public Monitor(String monitor_id) throws MalformedURLException, RemoteException {
		 
		 	monitor = monitor_id;
		 	frame123.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame123.setBounds(100, 100, 619, 435);
			contentPane123 = new JPanel();
			contentPane123.setBorder(new EmptyBorder(5, 5, 5, 5));
			frame123.setContentPane(contentPane123);
			contentPane123.setLayout(null);
			
			comboBox1 = new JComboBox();
			comboBox1.setBounds(10, 11, 169, 29);
			contentPane123.add(comboBox1);
			
			JButton btnNewButton = new JButton("Search senssor id");
			btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
			btnNewButton.setBounds(189, 11, 117, 29);
			contentPane123.add(btnNewButton);
			btnNewButton.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	btnNewButtonActionPerformed(evt);
	            }
	        });
			
			
			textPane123 = new JTextPane();
			textPane123.setBounds(10, 78, 309, 307);
			contentPane123.add(textPane123);
			
			JLabel lblNewLabel = new JLabel("Sensor Readings");
			lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
			lblNewLabel.setBounds(111, 51, 108, 23);
			contentPane123.add(lblNewLabel);
			
			textPane_1234 = new JTextPane();
			textPane_1234.setBounds(329, 78, 264, 307);
			contentPane123.add(textPane_1234);
			
			JLabel lblNewLabel_1 = new JLabel("Monitors");
			lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
			lblNewLabel_1.setBounds(432, 51, 61, 23);
			contentPane123.add(lblNewLabel_1);
			
			
			// call the remote object of the remote service in the rmi registry
			
			
			try {
			    alarmobject = (alarmService) Naming.lookup("//localhost/monitorInterface");
				
				alarmobject.addListener(monitor);
			
				setmonitors(alarmobject.getAllmonitors());
				setsensors(alarmobject. getAllSensors());
				
			} catch (NotBoundException e) {
				
				System.out.println(e);
			}
			
			
	        
	        
	        
			
			
			

	 }
	 
	 /*
	  * call the remote objects for the button clicks and interface component actions
	  */
	 private void btnNewButtonActionPerformed(java.awt.event.ActionEvent evt) {
			
			String sensor = comboBox1.getSelectedItem().toString();
			try {
				if(sensor.equals("All")) {
				
					setsensorTempratureDetailsReadings(alarmobject.getTemperatureDetails());
				
				
				
				}
				else {
				
					setsensorTempratureDetailsReading(alarmobject.getTemperatureDetailsOfsensor(sensor));
					
				}
	 		} 
			catch (RemoteException e) {
	 			System.out.println(e);
	 		}
			
	       
		}
	 
	 private void setmonitors(String[] arr) {
		 
		 textPane_1234.setText(null);
		 for(int j=0;j<arr.length;j++) {
			 String monitor = arr[j];
			 
			 
			 textPane123.setText(monitor+"\n\n");
			 
			
		 }
		
		 
		 
		 
	 }
	 
	 private void setsensors(String[] sensor) {
		 
		 comboBox1.removeAll();
		 comboBox1.addItem("All");
		 
     	for(int y=0;y<sensor.length;y++){
     		comboBox1.addItem(sensor[y]);
     	}            	
    
		 
		 
	 }


	 private void setsensorTempratureDetailsReadings(String[] temperature) {
		 
		 textPane123.setText(null);
		 textPane123.setText("Sensor"+"\t"+"Temperature"+"\t"+"Smoke"+"\t"+"CO2 Level"+"\t"+"Battery"+"\n\n");
		 
		 for(int x=0;x<temperature.length;x++) {
			 String details = temperature[x];
			 
			 String[] sensor = details.split(":");
			 
			 textPane123.setText(sensor[0]+"\t"+sensor[1]+"\t"+sensor[2]+"\t"+sensor[3]+"\t"+sensor[4]+"\n\n");
			 
			
		 }
		 
		 
	 }
	 
	 private void setsensorTempratureDetailsReading(String temperature) {
		 
		 textPane123.setText(null);
		 textPane123.setText("Sensor"+"\t"+"Temperature"+"\t"+"Smoke"+"\t"+"CO2 Level"+"\t"+"Battery"+"\n\n");
		 
		 String[] sensor = temperature.split(":");
		 textPane123.setText(sensor[0]+"\t"+sensor[1]+"\t"+sensor[2]+"\t"+sensor[3]+"\t"+sensor[4]+"\n\n");
		 
	 }
	 
	
	 

}
