

import java.rmi.Remote;

// This remote interface is used to that describes the functions in the monitor server
 
public interface alarmService extends Remote {
	
	
	public String[] getAllSensors() throws
	java.rmi.RemoteException;
	public String[] getAllmonitors() throws
	java.rmi.RemoteException;
	public String getTemperatureDetailsOfsensor(String sensor) throws
	java.rmi.RemoteException;
	public String[] getTemperatureDetails() throws
	java.rmi.RemoteException;
	public void addListener(String listener )throws java.rmi.RemoteException;
	public void removeListener(String listener )throws java.rmi.RemoteException;

}
