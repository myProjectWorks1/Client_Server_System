
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MonitorServer extends UnicastRemoteObject implements
alarmService {
	
	
	// The class that implements the remote interface
	 
	
	private ArrayList<String> monitor_ = new ArrayList();

	private static HashMap<String,String> temperature = new HashMap<String,String>();
	
	private static HashMap<String,String> smoke_level = new HashMap<String,String>();
	
	private static HashMap<String,String> battery_level = new HashMap<String,String>();
	
	private static HashMap<String,String> co2 = new HashMap<String,String>();

	public MonitorServer() throws IOException{
	       super();
	       
	       try {
	    	   
	    	   

	    		File XmlFile1 = new File("TempratureReadings.xml");
	    		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
	    		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
	    		Document document1 = (Document) documentBuilder.parse(XmlFile1);
	    				
	    		
	    		((Node) document1.getDefaultRootElement()).normalize();

	    		System.out.println("Root element :" + document1.getDefaultRootElement().getName());
	    				
	    		NodeList nodeList = ((org.w3c.dom.Document) document1).getElementsByTagName("SensorReading");
	    				
	    	

	    		for (int temps = 0; temps < nodeList.getLength(); temps++) {

	    			Node nodes = nodeList.item(temps);
	    					
	    			String id1 = null;
	    			String temp1 = null;
	    			String smoke1 = null;
	    			String c021 = null;
	    			String battry1 = null;
	    		
	    			
	    			
	    					
	    			if (nodes.getNodeType() == Node.ELEMENT_NODE) {

	    				Element elements = (Element) nodes;

	    				id1 = elements.getAttribute("id");
	    				temp1 =  elements.getElementsByTagName("temperature").item(0).getTextContent();
	    				smoke1 = elements.getElementsByTagName("smoke").item(0).getTextContent();
	    				c021 = elements.getElementsByTagName("co2").item(0).getTextContent();
	    				battry1 = elements.getElementsByTagName("salary").item(0).getTextContent();
	    				
	    				temperature .put(id1, temp1);
	    				smoke_level.put(id1, smoke1);
	    				co2.put(id1, c021);
	    				battery_level.put(id1, battry1);

	    			}
	    		}
	    	    } catch (Exception e) {
	    		e.printStackTrace();
	    	    }
	    	  }
	
	
	
	
	
	
	// this method is used to return the temprature details of a  given senssor as a string
	@Override
	public String getTemperatureDetailsOfsensor(String sensor) throws RemoteException {
		
		
		String str = "";
		if(temperature.containsKey(sensor)) {
			str.concat(":"+temperature.get(sensor));
		}
		if(smoke_level.containsKey(sensor)) {
			str.concat(":"+smoke_level.get(sensor));
		}
		if(co2.containsKey(sensor)) {
			str.concat(":"+co2.get(sensor));
		}
		if(battery_level.containsKey(sensor)) {
			str.concat(":"+battery_level.get(sensor));
		}
		
		return str;
		
	}
	
	

	// This method is used to return  temprature details of all the senssors as array
	
	@Override
	public String[] getTemperatureDetails() throws RemoteException {
		
		String[] array = new String[temperature.size()];
		
		for(int j=0;j<temperature.size();j++) {
		
		for(String x : temperature.keySet()) {
			String update = x;
			if(temperature.containsKey(x)) {
				update.concat(":"+temperature.get(x));
			}
			if(smoke_level.containsKey(x)) {
				update.concat(":"+smoke_level.get(x));
			}
			if(co2.containsKey(x)) {
				update.concat(":"+co2.get(x));
			}
			if(battery_level.containsKey(x)) {
				update.concat(":"+battery_level.get(x));
			}
			array[j] = update;
		}	           
			
		}
		return array;
	}

	
	//This method is used to returns all the monitors that receive detials remotely from the server
	
	@Override
	public String[] getAllmonitors() throws RemoteException{
		String[] array2 = new String[monitor_.size()];
		
		for(int y = 0;y<monitor_.size();y++) {
			array2[y] = monitor_.get(y);
		}
		
		return array2;
		
	}
	
	
	// This method is used to return all the senssors
	@Override
	public String[] getAllSensors() throws RemoteException{
		String[] array1 = new String[temperature.size()];
		
		for(int z=0;z<temperature.size();z++) {
			
			for(String y : temperature.keySet()) {
				
				array1[z] = y;
			}	           
				
		}
		
		return array1;
	}
	
	
	
	// This method is used to that register a monitor as a listner
	@Override
	public void addListener(String listener) throws RemoteException {
		
		monitor_.add(listener);
		
	}


	//This methos is used to remove the registered monitors when they are left
	@Override
	public void removeListener(String listener) throws RemoteException {
		
		monitor_.remove(monitor_.indexOf(listener));
		
	}
	
	public static void main(String[] args) throws IOException {
		
		// registers the methods 
		 
		
		MonitorServer monitorserver_1 = new MonitorServer();

        Registry registry = LocateRegistry.createRegistry(6890);

        registry.rebind("monitorInterface", monitorserver_1);
         

	}

	
}
