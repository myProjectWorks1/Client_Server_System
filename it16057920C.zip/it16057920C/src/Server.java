


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;




public class Server extends UnicastRemoteObject{
    private static final int PORT = 9090;
    private static ServerSocket serSocket;
    private static Socket clientSocket = null;
    private static int co2;
    private static int temp;
    private static int battry_level;
    private static int smoke_level;
    private static int InSensor;
    static BufferedReader in1,in2;
    
    
    public Server() throws java.rmi.RemoteException{
        co2 = 0;
        temp = 0;
        battry_level= 0;
        smoke_level = 0;
        InSensor = 0;

    }
    
    
    
    
    
    
    public static void main(String[] args) throws Exception {
        System.out.println("The Server is running....");

        try {
            serSocket = new ServerSocket(PORT);
            Server server1 = new Server();
            File file1 = new File("C:\\Users\\Nethmi\\Desktop\\it16057920C\\src\\Sensors.txt");

            while (true) {
                clientSocket = serSocket.accept();
                server1.get_Readings();
                in2 = new BufferedReader(new FileReader(file1));
                String checked = "";
                String checked1 = "";
                checked1 = String.valueOf(InSensor);
                boolean status1 = false;
                while ((checked = in2.readLine()) != null) {
                    if (checked1.compareTo(checked) == 0) {
                        status1 = true;
                        //break;
                    }
                }

                if (status1 == false) {
                    PrintWriter SNamewriter = new PrintWriter(new BufferedWriter(new FileWriter(file1, true)));
//                    if(check == null){
//                        SNamewriter.println(0);
//                    }
                    
                    SNamewriter.println(InSensor);
                    SNamewriter.close();
                }
                in2.close();
            }

        } catch (IOException e) {
            System.err.println(e);
        } finally {
            serSocket.close();
        }

        
        
        
    }
    
    
    //access data
    public static void get_Readings() throws TransformerException, ParserConfigurationException {
        BufferedReader bufferreader = null;
        try {            
            bufferreader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException ex) {
            System.err.println(ex);
        }


        try {
            InSensor = bufferreader.read();
            co2 = bufferreader.read();
            temp = bufferreader.read();
            battry_level= bufferreader.read();
            smoke_level= bufferreader.read();
        } catch (IOException ex) {
            System.err.println(ex);
        }

        

        try {
            try(PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter("TempratureReadings.xml", true)))){ 
               
                writer.println(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime())+"\t\t"+InSensor+"\t\t"+co2+"\t\t"+temp+"\t\t"+battry_level+"\t\t"+smoke_level);
                writer.close();
            	//saveDetails s = new saveDetails();
            	Server save = new Server();
            
            	save.save(InSensor,temp,smoke_level,co2,battry_level);
            }}
            
        catch (IOException e) {
                System.err.println(e);
        }
   
    }
    private static void save(int id,int temp,int smoke,int co2,int battery) throws TransformerException, ParserConfigurationException, IOException {
    	
    	String id1 = String.valueOf(id);
    	String temp1 = String.valueOf(temp);
    	String smoke1 = String.valueOf(smoke);
    	String co21 = String.valueOf(co2);
    	String battery1 = String.valueOf(battery);
		if((id1!=null)&&(temp1!=null)&&(smoke1!=null)&&(co21!=null)&&(battery1!=null)) {
			
			System.out.println("save method called in server");
		
			FileWriter stationfile = new FileWriter("TempratureReading.txt", true);
			
			DocumentBuilderFactory dBFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dBFactory.newDocumentBuilder();

			Document doc1 = dBuilder.newDocument();

			Element element1 = doc1.createElement("SensorReading");
			doc1.appendChild(element1);
			
			Attr attr = doc1.createAttribute("sensorid");
			attr.setValue(id1);
			element1.setAttributeNode(attr);

			Element temperature = doc1.createElement("Temperature");
			temperature.appendChild(doc1.createTextNode(temp1));
			element1.appendChild(temperature);

			Element smokes = doc1.createElement("smoke");
			smokes.appendChild(doc1.createTextNode(smoke1));
			element1.appendChild(smokes);
			
			Element co2s = doc1.createElement("Co2");
			co2s.appendChild(doc1.createTextNode(co21));
			element1.appendChild(co2s);
			
			Element batt = doc1.createElement("Battery");
			batt.appendChild(doc1.createTextNode(battery1));
			element1.appendChild(batt);

			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformerOBJ = tFactory.newTransformer();
			DOMSource source = new DOMSource(doc1);

			StreamResult streamResultOBJ = new StreamResult(stationfile);

			transformerOBJ.transform(source, streamResultOBJ);
        
		}
		else {
			return;
		}

	}
	
    
    //method to check the where there is high temprature
    public void calcReadings(int smoke_level, int temp){
        if(smoke_level > 7 || temp > 50){
            notifyMonitoringStations();
        }
    }

    
    //method to notify monitoring stations
    public void notifyMonitoringStations(){
        
        try {
			String registration = "//localhost/Alert";

			Remote remoteService = Naming.lookup(registration);
			Alert monitor1 = (Alert)remoteService;
			
		} catch (MalformedURLException mue) {
                    System.err.println(mue);
		} catch (RemoteException re) {
                    System.err.println(re);
		} catch (NotBoundException nbe) {
                    System.err.println(nbe);
		}
        
        
    }
    
}
