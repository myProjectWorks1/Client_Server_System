
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class MonitorAuthenticate {

	/*
	 * initialize the variables
	 */
	JFrame frame = new JFrame("MonitorAuthentication");
	private JPanel contentPane;
	
	private JTextField MAmonitorid;
	private JPasswordField MApassword;
	private JTextField MAAmonitorid;
	private JPasswordField MAApassword;
	private JPasswordField MAAconfirmpass;
	
	public MonitorAuthenticate() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 544, 350);
		contentPane = new JPanel();
		contentPane.setBackground(Color.white);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Monitor Login");
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel.setBounds(186, 11, 142, 29);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Sign In");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setBounds(81, 66, 69, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Sign Up");
		lblNewLabel_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2.setBounds(366, 66, 69, 29);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Monitor ID");
		lblNewLabel_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(10, 112, 82, 29);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(10, 156, 82, 30);
		contentPane.add(lblNewLabel_4);
		
		MAmonitorid = new JTextField();
		MAmonitorid.setBounds(94, 111, 124, 29);
		contentPane.add(MAmonitorid);
		MAmonitorid.setColumns(10);
		
		MApassword = new JPasswordField();
		MApassword.setBounds(94, 157, 124, 29);
		contentPane.add(MApassword);
		MApassword.setColumns(10);
		
		JButton silogin = new JButton("Sign In");
		silogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	MAloginActionPerformed(evt);
            }
        });
		silogin.setForeground(Color.DARK_GRAY);
		silogin.setFont(new Font("Times New Roman", Font.BOLD, 14));
		silogin.setBounds(128, 203, 89, 28);
		contentPane.add(silogin);
		
		JButton sicancel = new JButton("Cancel");
		sicancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	MAcancelActionPerformed(evt);
            }
        });
		sicancel.setForeground(Color.DARK_GRAY);
		sicancel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		sicancel.setBounds(29, 203, 89, 28);
		contentPane.add(sicancel);
		
		JLabel lblNewLabel_5 = new JLabel("Sensor ID");
		lblNewLabel_5.setForeground(Color.DARK_GRAY);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_5.setBounds(273, 112, 89, 28);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Password");
		lblNewLabel_6.setForeground(Color.DARK_GRAY);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_6.setBounds(274, 157, 89, 28);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Confirmation");
		lblNewLabel_7.setForeground(Color.DARK_GRAY);
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_7.setBounds(274, 202, 89, 26);
		contentPane.add(lblNewLabel_7);
		
		MAAmonitorid = new JTextField();
		MAAmonitorid.setBounds(366, 113, 124, 29);
		contentPane.add(MAAmonitorid);
		MAAmonitorid.setColumns(10);
		
		MAApassword = new JPasswordField();
		MAApassword.setBounds(366, 156, 124, 29);
		contentPane.add(MAApassword);
		MAApassword.setColumns(10);
		
		MAAconfirmpass = new JPasswordField();
		MAAconfirmpass.setBounds(366, 199, 124, 29);
		contentPane.add(MAAconfirmpass);
		MAAconfirmpass.setColumns(10);
		
		JButton MAlogin = new JButton("Sign Up");
		MAlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	MAAloginActionPerformed(evt);
            }
        });
		MAlogin.setForeground(Color.DARK_GRAY);
		MAlogin.setFont(new Font("Times New Roman", Font.BOLD, 14));
		MAlogin.setBounds(401, 239, 89, 29);
		contentPane.add(MAlogin);
		
		JButton MAcancel = new JButton("Cancel");
		MAcancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	MAAcancelActionPerformed(evt);
            }
        });
		MAcancel.setForeground(Color.DARK_GRAY);
		MAcancel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		MAcancel.setBounds(302, 239, 89, 29);
		contentPane.add(MAcancel);
	}
	
	/*
	 * 
	 */
	
	private void MAloginActionPerformed(java.awt.event.ActionEvent evt) {
		
		String sensor_ID = MAmonitorid.getText();
        String  sensor_password = MApassword.getText();

        try {
            monitorlogin(sensor_ID,sensor_password);
        } catch (Exception e) {
            System.out.println(e);
        }
		
	}
	
	
	 //This method is used to clear the username and password details when click the cancel button

	private void MAcancelActionPerformed(java.awt.event.ActionEvent evt) {
		
		MAmonitorid.setText(null);
		MApassword.setText(null);
		
	}
	
	
	//This method used to   create a account when sign up for a new monitor
	 
	private void MAAloginActionPerformed(java.awt.event.ActionEvent evt) {
		
		String addsensor_ID = MAAmonitorid.getText();
        String senssor_password = MAApassword.getText();
        String confirm_password = MAAconfirmpass.getText();

        if (senssor_password.equals(confirm_password)) {
            try {
                AddMonitorDetails(addsensor_ID, senssor_password);
               
            } catch (Exception e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Password is incorrect.try again later!");
        }

		
	}
	
	private void MAAcancelActionPerformed(java.awt.event.ActionEvent evt) {
		
		MAAmonitorid.setText(null);
		MAApassword.setText(null);
		MAAconfirmpass.setText(null);
		
	}
	
	
	public void AddMonitorDetails(String lgmonitorid, String lgPassword) throws Exception {

        

        boolean status = CheckMonitors(lgmonitorid);

        

        if (status) {
            FileWriter stationfile = new FileWriter("C:\\Users\\Nethmi\\Desktop\\it16057920C\\src\\monitorslog.xml", true);

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

            Document document = dBuilder.newDocument();

            Element element = document.createElement("Monitors");
            document.appendChild(element);

            Attr attribute = document.createAttribute("monitorid");
            attribute.setValue(lgmonitorid);
            element.setAttributeNode(attribute);

            Element lginpassword = document.createElement("monitorpassword");
            lginpassword.appendChild(document.createTextNode(lgPassword));
            element.appendChild(lginpassword);

            TransformerFactory tfFactory = TransformerFactory.newInstance();
            Transformer transformer1 = tfFactory.newTransformer();
            DOMSource domsource = new DOMSource(document);

            StreamResult sResult = new StreamResult(stationfile);

            transformer1.transform(domsource, sResult);
            
            MAAmonitorid.setText(null);
            MAApassword.setText(null);
            MAAconfirmpass.setText(null);
            
        } else {
            JOptionPane.showMessageDialog(null, "Monitor Already Exists.Enter another username and password !");
        }
    }
	
	
	// This method is used to check whether that monitor has already registerd or not
	 
	public boolean CheckMonitors(String lgmonitorid) throws Exception {
        boolean status = false;
        File MonitorsLogin  = new File("C:\\Users\\Nethmi\\Desktop\\it16057920C\\src\\monitorslog.xml");
        FileReader readfilestatus = new FileReader(MonitorsLogin);
        BufferedReader bufferedReader1 = new BufferedReader(readfilestatus);
        String Lgmonitor = bufferedReader1.readLine();

        while (Lgmonitor != null) {
            if (Lgmonitor.contains(lgmonitorid)) {
                status = false;
                break;
            } else {
                status = true;
            }
            Lgmonitor = bufferedReader1.readLine();
        }
       
        return status;
    }
	
	//This method used to validate the user login that user enter the correct password or not
	
	private boolean ValidateUserlogin(String monitorid, String Password) throws Exception {
        boolean status = false;
        File monitorslogin = new File("monitorslogin.xml");
        FileReader readfilelogin = new FileReader(monitorslogin);
        BufferedReader bufferedReader2 = new BufferedReader(readfilelogin);
        String monitor = bufferedReader2.readLine();

        while (monitor != null) {
            if (monitor.contains(monitorid) && monitor.contains(Password)) {
                status = true;
                break;
            } else {
                status = false;
            }
            monitor = bufferedReader2.readLine();
        }
        
        return status;
    }
	
	
	//This method is used to login to the monitor
	private void monitorlogin(String monitorid, String password) throws Exception {
        
        boolean status = ValidateUserlogin(monitorid, password);
        if (status) {
            JOptionPane.showMessageDialog(null, "Welcome!");
            frame.dispose();
            Monitor monitor = new Monitor(monitorid);
            monitor.frame123.setVisible(true);
          
        } else {
            JOptionPane.showMessageDialog(null, "failed to login.try again later!");
        }
    }
	
	
	

	
	public static void main(String[] args) {
		
		MonitorAuthenticate newauth = new MonitorAuthenticate();
		newauth.frame.setVisible(true);
		
		
	}


}
