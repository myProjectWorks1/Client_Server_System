/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class Sensor {
    
    private static int co2;
    private static int temp;
    private static int battry_level;
    private static int smoke_level;
    private static String serverAddress = "192.168.13.1";
    DecimalFormat df = new DecimalFormat("#.##");
    private static int sensorID;
    

    
    public Sensor() {
        co2 = 0;
        temp = 0;
        battry_level = 0;
        smoke_level = 0;
        sensorID = 0;
    }

     //In here generating random values for the temprature details
    static Runnable pr1 = new Runnable() {

        @Override
        public void run() {
            Random rand = new Random();
            smoke_level = rand.nextInt((10 - 0) + 1) + 10;
            temp = rand.nextInt((40 - 0) + 1) + 0;
            co2 = rand.nextInt((300 - 70) + 1) + 70;
            battry_level = rand.nextInt((100 - 50) + 1) + 50;
            
        }
    };
    
    //In here sending the reading details to the server
    static Runnable pr2 = new Runnable() {

        @Override
        public void run() {

            System.out.println("Enter sensor number :");
            Scanner sc = new Scanner(System.in); 
            sensorID = sc.nextInt();

            try {
                Socket senssorSocket = new Socket(serverAddress, 9090);

                PrintWriter out = new PrintWriter(senssorSocket.getOutputStream(), true);
                out.write(sensorID);
                
                out.write(battry_level);
                out.write(temp);
                out.write(co2);
                out.write(smoke_level);
                out.flush();
                out.close();
            } catch (IOException ex) {
                System.err.println(ex);
            }


        }
    };
    
   


    
    public static void main(String[] args) throws Exception {
        Sensor sensor1 = new Sensor();
        //executing the thread in 5 mintues intervals
        ScheduledExecutorService executor1 =Executors.newSingleThreadScheduledExecutor();
        executor1.scheduleAtFixedRate(pr1, 0, 5, TimeUnit.SECONDS); 
        
        //sending periodic updates to the server
        ScheduledExecutorService executor2 =Executors.newSingleThreadScheduledExecutor();
        executor2.scheduleAtFixedRate(pr2, 0, 5, TimeUnit.SECONDS); 
    }
}
