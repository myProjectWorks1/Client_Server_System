Steps-
	1. After starting server and sensor, enter a sensor number.
		eg :- sensor number - 1,2,3,.....

	